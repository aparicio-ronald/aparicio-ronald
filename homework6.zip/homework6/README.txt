{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf100
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 I made a web app using Ruby on Rails and it uses SQLite as a database. If the program needs to be run, you will have to install Ruby on Rails on your computer and open the file homework6 and run it using the command "rails s" in the terminal/command prompt. Once the server is running, you will use port 3000 to access the web app. I have posted images of the web app,  some of the images show you the verification I used for zip code, phone number, and email. There is also images of the flight table where it has a drop down select for the airline and images of the final results.  }