require "application_system_test_case"

class FlightsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit flights_url
  #
  #   assert_selector "h1", text: "Flight"
  # end
end
