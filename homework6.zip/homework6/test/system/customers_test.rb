require "application_system_test_case"

class CustomersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit customers_url
  #
  #   assert_selector "h1", text: "Customer"
  # end
end
