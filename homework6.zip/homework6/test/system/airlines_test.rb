require "application_system_test_case"

class AirlinesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit airlines_url
  #
  #   assert_selector "h1", text: "Airline"
  # end
end
