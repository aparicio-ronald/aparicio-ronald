class CreateFlights < ActiveRecord::Migration[5.1]
  def change
    create_table :flights do |t|
      t.string :origin_city
      t.string :destination_city

      t.timestamps
    end
  end
end
