class AddAirlineIdToFlight < ActiveRecord::Migration[5.1]
  def change
    add_column :flights, :airline_id, :integer
  end
end
