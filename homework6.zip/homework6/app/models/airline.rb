class Airline < ApplicationRecord
	has_many :flights
end
