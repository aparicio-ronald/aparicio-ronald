class Flight < ApplicationRecord
	belongs_to :airline
end
