class Customer < ApplicationRecord
	validates :zip_code, :length => {:minimum => 5, :maximum => 5}
	validates :phone_number, format: { with: /\A\+\d{2}[-.](\d{10}|\(?\d{3}\)?[-. ]\d{3}[-.]\d{4})\z/, message: "format +12-123-123-1234 or +12.123.123.1234 need to include 2 digit country code and area code" }
	validates :email, format: /@/ 
end