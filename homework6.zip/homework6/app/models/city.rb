class City < ApplicationRecord
end
